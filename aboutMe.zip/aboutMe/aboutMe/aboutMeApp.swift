//
//  aboutMeApp.swift
//  aboutMe
//
//  Created by Laura Jun on 2/11/26.
//

import SwiftUI

@main
struct aboutMeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
