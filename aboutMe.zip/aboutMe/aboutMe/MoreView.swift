//
//  MoreView.swift
//  aboutMe
//
//  Created by Laura Jun on 2/11/26.
//

import SwiftUI

struct MoreView: View {
    var body: some View {
        NavigationStack {
            Form {
                Section("Skills"){
                    Text("Xcode")
                    Text("Sword fighting")
                    Text("Kotlin Developer")
                    Text("Ping Pong")
                }
                
                Section("Favorite Things to Eat"){
                    Text("Ramen")
                    Text("KBBQ")
                    Text("Tacos")
                    Text("Chinese Food")
                    Text("Everything")
                }
            }
            .navigationTitle("More Info")
        }
    }
}

#Preview {
    MoreView()
}
