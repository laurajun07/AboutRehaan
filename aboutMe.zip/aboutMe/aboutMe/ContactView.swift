//
//  ContactView.swift
//  aboutMe
//
//  Created by Laura Jun on 2/11/26.
//

import SwiftUI

struct ContactView: View {
    var body: some View {
        NavigationStack {
            VStack {
                Link(destination: URL(string: "instagram.com/rehaan7643")!) {
                    Text("Instagram")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                
                
                Link(destination: URL(string: "https://github.com/Rehaan12345")!) {
                    Text("GitHub")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                
                Link(destination: URL(string: "https://www.linkedin.com/in/rehaananjaria/")!) {
                    Text("LinkedIn")
                        .font(.largeTitle)
                        .padding()
                }
                .buttonBorderShape(.roundedRectangle(radius: 20))
                .buttonStyle(.borderedProminent)
                
                
            }
            .navigationTitle("Contact")
        }
    }
}

#Preview {
    ContactView()
}
