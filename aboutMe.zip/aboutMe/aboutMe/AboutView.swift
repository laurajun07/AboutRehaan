//
//  AboutView.swift
//  aboutMe
//
//  Created by Laura Jun on 2/11/26.
//

import SwiftUI

struct AboutView: View {
        let hobbies = ["hiking", "eating", "hobby horsing", "pogo jumping"]
        var body: some View {
            ZStack {
                Color.blue
                    .opacity(0.1)
                    .ignoresSafeArea()
                
            VStack {
                Image("Primary")
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(25)
                    .shadow(color: .blue, radius: 15)
                    .padding()
                
                Text("Hi, I'm Rehaan Anjaria!")
                    .font(.largeTitle)
                    .bold()
                    .fontDesign(.monospaced)
                
                Text("I love \(hobbies.formatted()).")
                
                HStack{
                    Image(systemName: "iphone.gen2")
                    Image(systemName: "macbook.gen2")
                    Image(systemName: "applewatch")
                    Image(systemName: "earpods")
                }
                .imageScale(.large)
                .padding()
                .glassEffect(.regular.interactive())
                
                
                Spacer()
                    .frame(height: 30)
                
                
                Text("Fun Fact")
                    .font(.title)
                
                Text("Knows 4 digits of pi")
                
                Spacer()
                    .frame(height: 20)
                
                Text("Favorite Apple Product")
                    .font(.title)
                Text("Pie")
                
            }
            .padding()
            . multilineTextAlignment(.center)
        }
    }
}

#Preview {
    AboutView()
}
